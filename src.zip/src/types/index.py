from typing import List, Dict, Union

# Define a type for a card
Card = str

# Define a type for a hand, which is a list of cards
Hand = List[Card]

# Define a type for the player's information
PlayerInfo = Dict[str, Union[str, int, Hand]]

# Define a type for the game state
GameState = Dict[str, Union[PlayerInfo, Hand, int, bool]]